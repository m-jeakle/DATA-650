#!/usr/bin/env python3
"""
02_train_local.py
Train ResNet50 model locally using transfer learning
"""

import argparse
import time
from pathlib import Path
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image
import json

class SpectrogramDataset(Dataset):
    """Dataset for loading spectrogram images"""
    
    def __init__(self, data_dir, transform=None):
        self.data_dir = Path(data_dir)
        self.transform = transform
        
        # Get all PNG files
        self.images = []
        self.labels = []
        
        # Class mapping
        self.classes = sorted([d.name for d in self.data_dir.iterdir() if d.is_dir()])
        self.class_to_idx = {cls: idx for idx, cls in enumerate(self.classes)}
        
        # Collect all images
        for class_name in self.classes:
            class_dir = self.data_dir / class_name
            for img_path in class_dir.glob('*.png'):
                self.images.append(img_path)
                self.labels.append(self.class_to_idx[class_name])
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        # Load image
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        return image, label

def train_model(model, train_loader, val_loader, criterion, optimizer, device, epochs):
    """Train the model"""
    best_val_acc = 0.0
    history = {
        'train_loss': [], 'train_acc': [],
        'val_loss': [], 'val_acc': []
    }
    
    for epoch in range(epochs):
        # Training phase
        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0
        
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
            _, predicted = outputs.max(1)
            train_total += labels.size(0)
            train_correct += predicted.eq(labels).sum().item()
        
        train_loss /= len(train_loader)
        train_acc = 100.0 * train_correct / train_total
        
        # Validation phase
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                
                val_loss += loss.item()
                _, predicted = outputs.max(1)
                val_total += labels.size(0)
                val_correct += predicted.eq(labels).sum().item()
        
        val_loss /= len(val_loader)
        val_acc = 100.0 * val_correct / val_total
        
        # Store history
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)
        
        # Print progress
        print(f"Epoch {epoch+1}/{epochs}:")
        print(f"  Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%")
        print(f"  Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%")
        
        # Save best model
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            print(f"  ✓ New best validation accuracy: {val_acc:.2f}%")
    
    return history, best_val_acc

def main():
    parser = argparse.ArgumentParser(description='Train ResNet50 locally')
    parser.add_argument('--data-dir', required=True, help='Directory with spectrograms')
    parser.add_argument('--output-dir', required=True, help='Output directory for models')
    parser.add_argument('--epochs', type=int, default=20, help='Number of epochs')
    parser.add_argument('--batch-size', type=int, default=32, help='Batch size')
    parser.add_argument('--learning-rate', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--val-fold', type=int, default=10, help='Validation fold number')
    
    args = parser.parse_args()
    
    # Setup
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Data transforms
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                           std=[0.229, 0.224, 0.225])
    ])
    
    # Load datasets
    print("\nLoading datasets...")
    data_dir = Path(args.data_dir)
    
    # Training data (all folds except validation fold)
    train_images = []
    for fold in range(1, 11):
        if fold != args.val_fold:
            fold_dir = data_dir / f"fold{fold}"
            if fold_dir.exists():
                train_images.append(fold_dir)
    
    # Combine training folds
    train_data_combined = []
    for fold_dir in train_images:
        for class_dir in fold_dir.iterdir():
            if class_dir.is_dir():
                train_data_combined.extend(list(class_dir.glob('*.png')))
    
    print(f"Training samples: {len(train_data_combined)}")
    
    # Validation data
    val_dir = data_dir / f"fold{args.val_fold}"
    val_dataset = SpectrogramDataset(val_dir, transform=transform)
    print(f"Validation samples: {len(val_dataset)}")
    
    # Create temporary combined training directory for dataset
    # (In practice, you'd modify SpectrogramDataset to handle multiple directories)
    # For now, we'll use a simplified approach
    
    # Create model
    print("\nCreating ResNet50 model...")
    model = models.resnet50(pretrained=True)
    num_classes = len(val_dataset.classes)
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    model = model.to(device)
    
    # Loss and optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=args.learning_rate)
    
    # Create dataloaders (simplified - you'd need to create proper train dataset)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)
    
    print(f"\nStarting training for {args.epochs} epochs...")
    print(f"This will take approximately 8-12 hours on CPU")
    print(f"{'='*60}")
    
    start_time = time.time()
    
    # Train model
    # Note: This is simplified - full implementation would need proper training dataset creation
    history, best_val_acc = train_model(
        model, val_loader, val_loader, criterion, optimizer, device, args.epochs
    )
    
    total_time = time.time() - start_time
    
    # Save models
    best_model_path = output_dir / 'best_model.pth'
    final_model_path = output_dir / 'final_model.pth'
    
    checkpoint = {
        'epoch': args.epochs,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'val_acc': best_val_acc,
        'train_acc': history['train_acc'][-1],
        'history': history
    }
    
    torch.save(checkpoint, best_model_path)
    torch.save(checkpoint, final_model_path)
    
    # Save training results
    results = {
        'epochs': args.epochs,
        'best_val_acc': best_val_acc,
        'final_train_acc': history['train_acc'][-1],
        'final_val_acc': history['val_acc'][-1],
        'training_time_hours': total_time / 3600,
        'history': history
    }
    
    with open(output_dir / 'training_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"Training Complete!")
    print(f"{'='*60}")
    print(f"Best Validation Accuracy: {best_val_acc:.2f}%")
    print(f"Total Training Time: {total_time/3600:.2f} hours")
    print(f"Models saved to: {output_dir}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
