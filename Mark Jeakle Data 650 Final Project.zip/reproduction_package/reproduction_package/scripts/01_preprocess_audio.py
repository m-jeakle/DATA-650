#!/usr/bin/env python3
"""
01_preprocess_audio.py
Convert UrbanSound8K audio files to mel-spectrogram images
"""

import os
import argparse
import pandas as pd
import librosa
import librosa.display
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from tqdm import tqdm

def create_spectrogram(audio_path, output_path, sample_rate=22050, n_mels=128, img_size=224):
    """Convert audio file to mel-spectrogram image"""
    try:
        # Load audio
        y, sr = librosa.load(audio_path, sr=sample_rate)
        
        # Generate mel-spectrogram
        mel_spec = librosa.feature.melspectrogram(
            y=y, 
            sr=sr,
            n_fft=2048,
            hop_length=512,
            n_mels=n_mels
        )
        
        # Convert to log scale (dB)
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
        
        # Create figure
        plt.figure(figsize=(img_size/100, img_size/100), dpi=100)
        librosa.display.specshow(mel_spec_db, sr=sr, x_axis='time', y_axis='mel')
        plt.axis('off')
        plt.tight_layout(pad=0)
        
        # Save
        plt.savefig(output_path, bbox_inches='tight', pad_inches=0)
        plt.close()
        
        return True
    except Exception as e:
        print(f"Error processing {audio_path}: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description='Convert audio to spectrograms')
    parser.add_argument('--audio-dir', required=True, help='Directory with audio folders (fold1, fold2, etc.)')
    parser.add_argument('--metadata', required=True, help='Path to UrbanSound8K.csv')
    parser.add_argument('--output-dir', required=True, help='Output directory for spectrograms')
    parser.add_argument('--sample-rate', type=int, default=22050, help='Audio sample rate')
    parser.add_argument('--n-mels', type=int, default=128, help='Number of mel bands')
    parser.add_argument('--img-size', type=int, default=224, help='Output image size')
    
    args = parser.parse_args()
    
    # Load metadata
    print("Loading metadata...")
    metadata = pd.read_csv(args.metadata)
    print(f"Found {len(metadata)} audio files")
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Process each fold
    total_processed = 0
    total_failed = 0
    
    for fold in range(1, 11):
        fold_name = f"fold{fold}"
        print(f"\nProcessing {fold_name}...")
        
        # Get files for this fold
        fold_files = metadata[metadata['fold'] == fold]
        
        # Create output directory for this fold
        fold_output = output_dir / fold_name
        fold_output.mkdir(exist_ok=True)
        
        # Create class subdirectories
        for class_name in metadata['class'].unique():
            (fold_output / class_name).mkdir(exist_ok=True)
        
        # Process each file
        for idx, row in tqdm(fold_files.iterrows(), total=len(fold_files)):
            # Input path
            audio_file = row['slice_file_name']
            audio_path = Path(args.audio_dir) / fold_name / audio_file
            
            # Output path
            output_file = audio_file.replace('.wav', '.png')
            output_path = fold_output / row['class'] / output_file
            
            # Skip if already exists
            if output_path.exists():
                total_processed += 1
                continue
            
            # Create spectrogram
            success = create_spectrogram(
                audio_path, 
                output_path,
                sample_rate=args.sample_rate,
                n_mels=args.n_mels,
                img_size=args.img_size
            )
            
            if success:
                total_processed += 1
            else:
                total_failed += 1
    
    print(f"\n{'='*60}")
    print(f"Processing Complete!")
    print(f"{'='*60}")
    print(f"Total spectrograms created: {total_processed}")
    print(f"Failed: {total_failed}")
    print(f"Output directory: {output_dir}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
