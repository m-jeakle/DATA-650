"""
AGGRESSIVE STRESS TEST - Push to Failure
Progressively increases load to find breaking points
"""

import asyncio
import aiohttp
import boto3
import time
import json
import random
import statistics
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import concurrent.futures

class AggressiveStressTest:
    """Stress test designed to overwhelm systems and find limits"""
    
    def __init__(self, endpoint_name, local_url, test_folder):
        self.endpoint_name = endpoint_name
        self.local_url = local_url
        self.test_folder = Path(test_folder)
        
        # AWS client with increased timeout
        self.sagemaker_runtime = boto3.client(
            'sagemaker-runtime', 
            region_name='us-east-2',
            config=boto3.session.Config(
                read_timeout=60,
                connect_timeout=60,
                retries={'max_attempts': 0}  # No retries - we want to see failures
            )
        )
        
        # Find test images
        self.test_images = list(self.test_folder.glob('**/*.png'))
        print(f"Found {len(self.test_images)} test spectrograms")
        
        if not self.test_images:
            raise ValueError(f"No PNG files found in {test_folder}")
        
        # Results storage
        self.results = {
            'aws': {'success': [], 'errors': []},
            'local': {'success': [], 'errors': []}
        }
        
        self.start_time = None
        self.phase_results = []  # Track results per load phase
    
    def test_aws_sync(self, image_path):
        """Test AWS endpoint (synchronous)"""
        start_time = time.time()
        
        try:
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            inference_start = time.time()
            response = self.sagemaker_runtime.invoke_endpoint(
                EndpointName=self.endpoint_name,
                ContentType='image/png',
                Body=image_data
            )
            inference_time = time.time() - inference_start
            
            result = json.loads(response['Body'].read().decode())
            
            return {
                'endpoint': 'AWS',
                'timestamp': time.time(),
                'response_time': time.time() - start_time,
                'inference_time': inference_time,
                'predicted_class': result.get('predicted_class'),
                'confidence': result.get('confidence'),
                'success': True
            }
            
        except Exception as e:
            return {
                'endpoint': 'AWS',
                'timestamp': time.time(),
                'response_time': time.time() - start_time,
                'error': str(e),
                'success': False
            }
    
    async def test_local_async(self, session, image_path):
        """Test local endpoint (async)"""
        start_time = time.time()
        
        try:
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            async with session.post(
                self.local_url,
                data=image_data,
                headers={'Content-Type': 'image/png'},
                timeout=aiohttp.ClientTimeout(total=60)
            ) as response:
                
                response_data = await response.json()
                
                return {
                    'endpoint': 'Local',
                    'timestamp': time.time(),
                    'response_time': time.time() - start_time,
                    'inference_time': response_data.get('inference_time_ms', 0) / 1000,
                    'predicted_class': response_data.get('predicted_class'),
                    'confidence': response_data.get('confidence'),
                    'system_metrics': response_data.get('system_metrics', {}),
                    'success': response.status == 200
                }
                
        except Exception as e:
            return {
                'endpoint': 'Local',
                'timestamp': time.time(),
                'response_time': time.time() - start_time,
                'error': str(e),
                'success': False
            }
    
    async def stress_phase(self, num_requests, concurrent_limit, phase_name):
        """Run one stress phase with specified concurrency"""
        print(f"\n{'='*80}")
        print(f"PHASE: {phase_name}")
        print(f"Requests: {num_requests} | Concurrency: {concurrent_limit}")
        print(f"{'='*80}")
        
        phase_start = time.time()
        phase_results = {'aws': {'success': [], 'errors': []}, 'local': {'success': [], 'errors': []}}
        
        # Random test images
        test_images = [random.choice(self.test_images) for _ in range(num_requests)]
        
        # Thread pool for AWS (synchronous)
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=concurrent_limit)
        
        # Async session for Local
        connector = aiohttp.TCPConnector(limit=concurrent_limit)
        
        try:
            async with aiohttp.ClientSession(connector=connector) as session:
                # Launch ALL requests simultaneously
                aws_futures = [executor.submit(self.test_aws_sync, img) for img in test_images]
                local_tasks = [self.test_local_async(session, img) for img in test_images]
                
                # Wait for all to complete
                print(f"Launching {len(test_images)} requests to each endpoint simultaneously...")
                
                # Gather AWS results
                aws_results = await asyncio.gather(
                    *[asyncio.get_event_loop().run_in_executor(None, f.result) for f in aws_futures],
                    return_exceptions=True
                )
                
                # Gather Local results
                local_results = await asyncio.gather(*local_tasks, return_exceptions=True)
                
                # Process results
                for result in aws_results:
                    if isinstance(result, Exception):
                        phase_results['aws']['errors'].append({'error': str(result)})
                    elif result['success']:
                        phase_results['aws']['success'].append(result)
                    else:
                        phase_results['aws']['errors'].append(result)
                
                for result in local_results:
                    if isinstance(result, Exception):
                        phase_results['local']['errors'].append({'error': str(result)})
                    elif result['success']:
                        phase_results['local']['success'].append(result)
                    else:
                        phase_results['local']['errors'].append(result)
        
        finally:
            executor.shutdown(wait=True)
        
        phase_duration = time.time() - phase_start
        
        # Store phase results
        phase_summary = {
            'phase': phase_name,
            'requests': num_requests,
            'concurrency': concurrent_limit,
            'duration': phase_duration,
            'aws': {
                'success': len(phase_results['aws']['success']),
                'errors': len(phase_results['aws']['errors']),
                'success_rate': len(phase_results['aws']['success']) / num_requests * 100
            },
            'local': {
                'success': len(phase_results['local']['success']),
                'errors': len(phase_results['local']['errors']),
                'success_rate': len(phase_results['local']['success']) / num_requests * 100
            }
        }
        
        self.phase_results.append(phase_summary)
        
        # Add to overall results
        self.results['aws']['success'].extend(phase_results['aws']['success'])
        self.results['aws']['errors'].extend(phase_results['aws']['errors'])
        self.results['local']['success'].extend(phase_results['local']['success'])
        self.results['local']['errors'].extend(phase_results['local']['errors'])
        
        # Print phase summary
        print(f"\n{'-'*80}")
        print(f"PHASE COMPLETE - Duration: {phase_duration:.2f}s")
        print(f"{'-'*80}")
        print(f"AWS:   {phase_summary['aws']['success']} success | "
              f"{phase_summary['aws']['errors']} errors | "
              f"{phase_summary['aws']['success_rate']:.1f}% success rate")
        print(f"Local: {phase_summary['local']['success']} success | "
              f"{phase_summary['local']['errors']} errors | "
              f"{phase_summary['local']['success_rate']:.1f}% success rate")
        
        # Small cooldown between phases
        await asyncio.sleep(2)
    
    async def run_progressive_stress_test(self):
        """Run progressively harder stress phases"""
        print(f"\n{'='*80}")
        print(f"AGGRESSIVE PROGRESSIVE STRESS TEST")
        print(f"{'='*80}")
        print(f"AWS Endpoint: {self.endpoint_name}")
        print(f"Local Endpoint: {self.local_url}")
        print(f"Strategy: Progressive load increase until failure")
        print(f"{'='*80}")
        
        self.start_time = time.time()
        
        # Progressive stress phases
        phases = [
            (100, 10, "Warmup - 100 requests, 10 concurrent"),
            (200, 25, "Light Load - 200 requests, 25 concurrent"),
            (500, 50, "Medium Load - 500 requests, 50 concurrent"),
            (1000, 100, "Heavy Load - 1000 requests, 100 concurrent"),
            (2000, 200, "Extreme Load - 2000 requests, 200 concurrent"),
        ]
        
        for num_requests, concurrent, phase_name in phases:
            await self.stress_phase(num_requests, concurrent, phase_name)
        
        # Final report
        self.generate_final_report()
    
    def calculate_metrics(self, results):
        """Calculate metrics from results"""
        if not results:
            return None
        
        response_times = [r['response_time'] for r in results]
        inference_times = [r.get('inference_time', 0) for r in results if r.get('inference_time')]
        confidences = [r['confidence'] for r in results if r.get('confidence')]
        
        metrics = {
            'total': len(results),
            'response_time': {
                'min': min(response_times),
                'max': max(response_times),
                'mean': statistics.mean(response_times),
                'median': statistics.median(response_times),
                'p95': sorted(response_times)[int(len(response_times) * 0.95)],
                'p99': sorted(response_times)[int(len(response_times) * 0.99)]
            }
        }
        
        if inference_times:
            metrics['inference_time'] = {
                'mean': statistics.mean(inference_times),
                'median': statistics.median(inference_times)
            }
        
        if confidences:
            metrics['confidence'] = {
                'mean': statistics.mean(confidences)
            }
        
        return metrics
    
    def generate_final_report(self):
        """Generate comprehensive final report"""
        print(f"\n{'='*80}")
        print(f"FINAL STRESS TEST REPORT")
        print(f"{'='*80}")
        
        total_duration = time.time() - self.start_time
        total_requests = len(self.results['aws']['success']) + len(self.results['aws']['errors'])
        
        print(f"\nTotal Test Duration: {total_duration:.2f} seconds")
        print(f"Total Requests Attempted: {total_requests}")
        
        # Phase-by-phase results
        print(f"\n{'='*80}")
        print(f"PHASE-BY-PHASE BREAKDOWN")
        print(f"{'='*80}")
        
        for phase in self.phase_results:
            print(f"\n{phase['phase']}")
            print(f"  Requests: {phase['requests']} | Concurrency: {phase['concurrency']} | Duration: {phase['duration']:.2f}s")
            print(f"  AWS:   {phase['aws']['success_rate']:.1f}% success ({phase['aws']['success']}/{phase['requests']})")
            print(f"  Local: {phase['local']['success_rate']:.1f}% success ({phase['local']['success']}/{phase['requests']})")
        
        # Overall metrics
        print(f"\n{'='*80}")
        print(f"OVERALL RESULTS")
        print(f"{'='*80}")
        
        aws_success = len(self.results['aws']['success'])
        aws_errors = len(self.results['aws']['errors'])
        local_success = len(self.results['local']['success'])
        local_errors = len(self.results['local']['errors'])
        
        print(f"\nAWS SageMaker:")
        print(f"  Success: {aws_success} ({aws_success/total_requests*100:.1f}%)")
        print(f"  Errors:  {aws_errors} ({aws_errors/total_requests*100:.1f}%)")
        
        aws_metrics = self.calculate_metrics(self.results['aws']['success'])
        if aws_metrics:
            print(f"  Avg Response Time: {aws_metrics['response_time']['mean']:.3f}s")
            print(f"  P95 Response Time: {aws_metrics['response_time']['p95']:.3f}s")
            print(f"  P99 Response Time: {aws_metrics['response_time']['p99']:.3f}s")
        
        print(f"\nLocal Model:")
        print(f"  Success: {local_success} ({local_success/total_requests*100:.1f}%)")
        print(f"  Errors:  {local_errors} ({local_errors/total_requests*100:.1f}%)")
        
        local_metrics = self.calculate_metrics(self.results['local']['success'])
        if local_metrics:
            print(f"  Avg Response Time: {local_metrics['response_time']['mean']:.3f}s")
            print(f"  P95 Response Time: {local_metrics['response_time']['p95']:.3f}s")
            print(f"  P99 Response Time: {local_metrics['response_time']['p99']:.3f}s")
            if 'inference_time' in local_metrics:
                print(f"  Avg Inference Time: {local_metrics['inference_time']['mean']:.3f}s")
        
        # Key insights
        print(f"\n{'='*80}")
        print(f"KEY INSIGHTS")
        print(f"{'='*80}")
        
        if aws_success > local_success:
            diff = aws_success - local_success
            print(f"✓ AWS handled {diff} MORE successful requests ({diff/total_requests*100:.1f}% better)")
        elif local_success > aws_success:
            diff = local_success - aws_success
            print(f"✓ Local handled {diff} MORE successful requests ({diff/total_requests*100:.1f}% better)")
        
        if aws_errors < local_errors:
            print(f"✓ AWS was MORE RELIABLE ({local_errors - aws_errors} fewer errors)")
        elif local_errors < aws_errors:
            print(f"✓ Local was MORE RELIABLE ({aws_errors - local_errors} fewer errors)")
        
        # Save results
        output = {
            'test_summary': {
                'total_duration': total_duration,
                'total_requests': total_requests,
                'phases': self.phase_results
            },
            'aws': {
                'success_count': aws_success,
                'error_count': aws_errors,
                'success_rate': aws_success / total_requests * 100,
                'metrics': aws_metrics
            },
            'local': {
                'success_count': local_success,
                'error_count': local_errors,
                'success_rate': local_success / total_requests * 100,
                'metrics': local_metrics
            }
        }
        
        filename = f"aggressive_stress_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(output, f, indent=2)
        
        print(f"\n{'='*80}")
        print(f"Results saved to: {filename}")
        print(f"{'='*80}\n")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--endpoint', default='urbansound-classifier-v1')
    parser.add_argument('--local-url', default='http://127.0.0.1:5000/invocations')
    parser.add_argument('--test-folder', required=True)
    
    args = parser.parse_args()
    
    tester = AggressiveStressTest(
        endpoint_name=args.endpoint,
        local_url=args.local_url,
        test_folder=args.test_folder
    )
    
    asyncio.run(tester.run_progressive_stress_test())


if __name__ == "__main__":
    main()
