"""
Final Comprehensive Stress Test - Urban Sound Classification System
Tests: 400, 500, 600, 700, 800, 900, 1000 concurrent users
Progressive load testing with detailed metrics and comparison

Configured for SageMaker endpoint + Local server with spectrogram images
WINDOWS VERSION - Fixed paths
"""

import asyncio
import aiohttp
import boto3
import time
import statistics
from datetime import datetime
from pathlib import Path
import json
import random
import os

# ==================== CONFIGURATION ====================
# UPDATE THESE VALUES:
SAGEMAKER_ENDPOINT_NAME = "urbansound-endpoint"  # Your SageMaker endpoint name
LOCAL_ENDPOINT = "http://127.0.0.1:5000/invocations"  # Local inference server
AWS_REGION = "us-east-2"

# Test images - Look in Downloads folder for spectrogram PNGs
# Will search for all PNG files in Downloads
TEST_IMAGES_FOLDER = r"C:\Users\markj\Downloads"  # Windows path to your Downloads
# ======================================================


class ComprehensiveStressTest:
    def __init__(self):
        self.results = {
            'aws': {},
            'local': {}
        }
        self.test_levels = [400, 500, 600, 700, 800, 900, 1000]
        
        # Initialize AWS client
        self.sagemaker_runtime = boto3.client(
            'sagemaker-runtime',
            region_name=AWS_REGION,
            config=boto3.session.Config(
                read_timeout=60,
                connect_timeout=60,
                retries={'max_attempts': 0}
            )
        )
        
        # Load test images - look for PNG files that look like spectrograms
        print(f"Searching for PNG images in {TEST_IMAGES_FOLDER}...")
        all_pngs = list(Path(TEST_IMAGES_FOLDER).glob('*.png'))
        
        # Filter to likely spectrogram images (ends with _image.png or contains 'image')
        self.test_images = [
            img for img in all_pngs 
            if '_image' in img.name.lower() or 'spectrogram' in img.name.lower()
        ]
        
        # If no specific spectrogram images found, use any PNGs
        if not self.test_images and all_pngs:
            print("No *_image.png files found, using all PNG files...")
            self.test_images = all_pngs[:100]  # Limit to first 100 to avoid issues
        
        print(f"Loaded {len(self.test_images)} test images")
        
        if not self.test_images:
            raise ValueError(f"No PNG files found in {TEST_IMAGES_FOLDER}\n"
                           f"Please ensure you have spectrogram PNG files in your Downloads folder.")
        
    def invoke_sagemaker_sync(self, image_path):
        """Invoke SageMaker endpoint synchronously"""
        start_time = time.time()
        
        try:
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            response = self.sagemaker_runtime.invoke_endpoint(
                EndpointName=SAGEMAKER_ENDPOINT_NAME,
                ContentType='image/png',
                Body=image_data
            )
            
            elapsed = time.time() - start_time
            result_json = json.loads(response['Body'].read().decode())
            
            return {
                'success': True,
                'response_time': elapsed,
                'status_code': 200,
                'result': result_json
            }
            
        except Exception as e:
            return {
                'success': False,
                'response_time': time.time() - start_time,
                'status_code': 'ERROR',
                'error': str(e)
            }
    
    async def invoke_local(self, session, image_path):
        """Invoke local endpoint asynchronously"""
        start_time = time.time()
        
        try:
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            async with session.post(
                LOCAL_ENDPOINT,
                data=image_data,
                headers={'Content-Type': 'image/png'},
                timeout=aiohttp.ClientTimeout(total=60)
            ) as response:
                elapsed = time.time() - start_time
                result = await response.json()
                
                return {
                    'success': response.status == 200,
                    'response_time': elapsed,
                    'status_code': response.status,
                    'result': result
                }
                
        except asyncio.TimeoutError:
            return {
                'success': False,
                'response_time': time.time() - start_time,
                'status_code': 'TIMEOUT',
                'error': 'Request timeout'
            }
        except Exception as e:
            return {
                'success': False,
                'response_time': time.time() - start_time,
                'status_code': 'ERROR',
                'error': str(e)
            }
    
    async def load_test_aws(self, concurrent_users):
        """Load test AWS SageMaker endpoint"""
        print(f"\n{'='*70}")
        print(f"Testing AWS SageMaker: {concurrent_users} concurrent users")
        print(f"{'='*70}")
        
        # Pick random images for this test
        test_sequence = [random.choice(self.test_images) for _ in range(concurrent_users)]
        
        # Run tests in parallel using ThreadPoolExecutor for synchronous boto3 calls
        from concurrent.futures import ThreadPoolExecutor
        
        start_time = time.time()
        with ThreadPoolExecutor(max_workers=min(concurrent_users, 100)) as executor:
            results = list(executor.map(self.invoke_sagemaker_sync, test_sequence))
        total_time = time.time() - start_time
        
        # Analyze results
        successful = [r for r in results if r['success']]
        failed = [r for r in results if not r['success']]
        response_times = [r['response_time'] for r in successful]
        
        # Calculate metrics
        metrics = {
            'concurrent_users': concurrent_users,
            'total_requests': len(results),
            'successful': len(successful),
            'failed': len(failed),
            'success_rate': (len(successful) / len(results) * 100) if results else 0,
            'failure_rate': (len(failed) / len(results) * 100) if results else 0,
            'total_duration': total_time,
            'throughput': len(results) / total_time if total_time > 0 else 0,
        }
        
        if response_times:
            metrics.update({
                'avg_response_time': statistics.mean(response_times),
                'median_response_time': statistics.median(response_times),
                'min_response_time': min(response_times),
                'max_response_time': max(response_times),
                'p95_response_time': sorted(response_times)[int(len(response_times) * 0.95)],
                'p99_response_time': sorted(response_times)[int(len(response_times) * 0.99)],
                'std_dev': statistics.stdev(response_times) if len(response_times) > 1 else 0,
            })
        else:
            metrics.update({
                'avg_response_time': 0,
                'median_response_time': 0,
                'min_response_time': 0,
                'max_response_time': 0,
                'p95_response_time': 0,
                'p99_response_time': 0,
                'std_dev': 0,
            })
        
        # Error analysis
        error_types = {}
        for result in failed:
            error = result.get('error', 'UNKNOWN')[:50]  # Truncate long errors
            error_types[error] = error_types.get(error, 0) + 1
        
        metrics['error_breakdown'] = error_types
        
        # Print results
        self._print_metrics(metrics, "AWS SageMaker")
        
        return metrics
    
    async def load_test_local(self, concurrent_users):
        """Load test local inference server"""
        print(f"\n{'='*70}")
        print(f"Testing Local Server: {concurrent_users} concurrent users")
        print(f"{'='*70}")
        
        # Pick random images for this test
        test_sequence = [random.choice(self.test_images) for _ in range(concurrent_users)]
        
        async with aiohttp.ClientSession() as session:
            # Create all tasks
            tasks = [
                self.invoke_local(session, img) 
                for img in test_sequence
            ]
            
            # Execute all requests concurrently
            start_time = time.time()
            results = await asyncio.gather(*tasks)
            total_time = time.time() - start_time
            
            # Analyze results
            successful = [r for r in results if r['success']]
            failed = [r for r in results if not r['success']]
            response_times = [r['response_time'] for r in successful]
            
            # Calculate metrics
            metrics = {
                'concurrent_users': concurrent_users,
                'total_requests': len(results),
                'successful': len(successful),
                'failed': len(failed),
                'success_rate': (len(successful) / len(results) * 100) if results else 0,
                'failure_rate': (len(failed) / len(results) * 100) if results else 0,
                'total_duration': total_time,
                'throughput': len(results) / total_time if total_time > 0 else 0,
            }
            
            if response_times:
                metrics.update({
                    'avg_response_time': statistics.mean(response_times),
                    'median_response_time': statistics.median(response_times),
                    'min_response_time': min(response_times),
                    'max_response_time': max(response_times),
                    'p95_response_time': sorted(response_times)[int(len(response_times) * 0.95)],
                    'p99_response_time': sorted(response_times)[int(len(response_times) * 0.99)],
                    'std_dev': statistics.stdev(response_times) if len(response_times) > 1 else 0,
                })
            else:
                metrics.update({
                    'avg_response_time': 0,
                    'median_response_time': 0,
                    'min_response_time': 0,
                    'max_response_time': 0,
                    'p95_response_time': 0,
                    'p99_response_time': 0,
                    'std_dev': 0,
                })
            
            # Error analysis
            error_types = {}
            for result in failed:
                error = result.get('error', 'UNKNOWN')[:50]
                error_types[error] = error_types.get(error, 0) + 1
            
            metrics['error_breakdown'] = error_types
            
            # Print results
            self._print_metrics(metrics, "Local Server")
            
            return metrics
    
    def _print_metrics(self, metrics, system_name):
        """Print formatted metrics"""
        print(f"\n{system_name} Results:")
        print(f"  Total Requests:     {metrics['total_requests']:,}")
        print(f"  Successful:         {metrics['successful']:,} ({metrics['success_rate']:.2f}%)")
        print(f"  Failed:             {metrics['failed']:,} ({metrics['failure_rate']:.2f}%)")
        print(f"  Total Duration:     {metrics['total_duration']:.2f}s")
        print(f"  Throughput:         {metrics['throughput']:.2f} req/s")
        
        if metrics['successful'] > 0:
            print(f"\n  Response Times:")
            print(f"    Average:          {metrics['avg_response_time']:.3f}s")
            print(f"    Median:           {metrics['median_response_time']:.3f}s")
            print(f"    Min:              {metrics['min_response_time']:.3f}s")
            print(f"    Max:              {metrics['max_response_time']:.3f}s")
            print(f"    95th Percentile:  {metrics['p95_response_time']:.3f}s")
            print(f"    99th Percentile:  {metrics['p99_response_time']:.3f}s")
            print(f"    Std Deviation:    {metrics['std_dev']:.3f}s")
        
        if metrics['error_breakdown']:
            print(f"\n  Error Breakdown:")
            for error_type, count in list(metrics['error_breakdown'].items())[:5]:  # Show top 5 errors
                print(f"    {error_type}: {count}")
    
    async def run_all_tests(self, test_aws=True, test_local=True):
        """Run all load tests progressively"""
        print("\n" + "="*70)
        print("FINAL COMPREHENSIVE STRESS TEST")
        print("Urban Sound Classification System")
        print(f"Test Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*70)
        
        for concurrent_users in self.test_levels:
            print(f"\n\n{'#'*70}")
            print(f"# LOAD LEVEL: {concurrent_users} CONCURRENT USERS")
            print(f"{'#'*70}")
            
            # Test AWS
            if test_aws:
                try:
                    aws_metrics = await self.load_test_aws(concurrent_users)
                    self.results['aws'][concurrent_users] = aws_metrics
                except Exception as e:
                    print(f"\nAWS Test Failed: {e}")
                    self.results['aws'][concurrent_users] = None
                
                # Cool down period
                print("\nCooling down for 10 seconds...")
                await asyncio.sleep(10)
            
            # Test Local
            if test_local:
                try:
                    local_metrics = await self.load_test_local(concurrent_users)
                    self.results['local'][concurrent_users] = local_metrics
                except Exception as e:
                    print(f"\nLocal Test Failed: {e}")
                    self.results['local'][concurrent_users] = None
                
                # Cool down before next level
                if concurrent_users != self.test_levels[-1]:
                    print("\nCooling down for 15 seconds before next level...")
                    await asyncio.sleep(15)
        
        # Generate final report
        self._generate_final_report()
    
    def _generate_final_report(self):
        """Generate comprehensive comparison report"""
        print("\n\n" + "="*70)
        print("FINAL COMPARATIVE ANALYSIS")
        print("="*70)
        
        # Summary table
        print("\n" + "-"*70)
        print("SUCCESS RATE COMPARISON")
        print("-"*70)
        print(f"{'Users':<10} {'AWS Success %':<20} {'Local Success %':<20} {'Winner':<15}")
        print("-"*70)
        
        for users in self.test_levels:
            aws_data = self.results['aws'].get(users)
            local_data = self.results['local'].get(users)
            
            aws_rate = aws_data['success_rate'] if aws_data else 0
            local_rate = local_data['success_rate'] if local_data else 0
            
            winner = "AWS" if aws_rate > local_rate else "Local" if local_rate > aws_rate else "Tie"
            
            print(f"{users:<10} {aws_rate:<20.2f} {local_rate:<20.2f} {winner:<15}")
        
        # Response time comparison
        print("\n" + "-"*70)
        print("AVERAGE RESPONSE TIME COMPARISON (seconds)")
        print("-"*70)
        print(f"{'Users':<10} {'AWS Avg':<20} {'Local Avg':<20} {'Faster':<15}")
        print("-"*70)
        
        for users in self.test_levels:
            aws_data = self.results['aws'].get(users)
            local_data = self.results['local'].get(users)
            
            aws_avg = aws_data['avg_response_time'] if aws_data and aws_data['successful'] > 0 else 0
            local_avg = local_data['avg_response_time'] if local_data and local_data['successful'] > 0 else 0
            
            if aws_avg > 0 and local_avg > 0:
                faster = "AWS" if aws_avg < local_avg else "Local"
            elif aws_avg > 0:
                faster = "AWS"
            elif local_avg > 0:
                faster = "Local"
            else:
                faster = "N/A"
            
            print(f"{users:<10} {aws_avg:<20.3f} {local_avg:<20.3f} {faster:<15}")
        
        # Throughput comparison
        print("\n" + "-"*70)
        print("THROUGHPUT COMPARISON (requests/second)")
        print("-"*70)
        print(f"{'Users':<10} {'AWS Throughput':<20} {'Local Throughput':<20} {'Higher':<15}")
        print("-"*70)
        
        for users in self.test_levels:
            aws_data = self.results['aws'].get(users)
            local_data = self.results['local'].get(users)
            
            aws_throughput = aws_data['throughput'] if aws_data else 0
            local_throughput = local_data['throughput'] if local_data else 0
            
            higher = "AWS" if aws_throughput > local_throughput else "Local" if local_throughput > aws_throughput else "N/A"
            
            print(f"{users:<10} {aws_throughput:<20.2f} {local_throughput:<20.2f} {higher:<15}")
        
        # Key findings
        print("\n" + "="*70)
        print("KEY FINDINGS")
        print("="*70)
        
        # Find breaking points
        aws_breaking_point = None
        local_breaking_point = None
        
        for users in self.test_levels:
            aws_data = self.results['aws'].get(users)
            local_data = self.results['local'].get(users)
            
            if aws_data and aws_data['success_rate'] < 95 and aws_breaking_point is None:
                aws_breaking_point = users
            
            if local_data and local_data['success_rate'] < 95 and local_breaking_point is None:
                local_breaking_point = users
        
        print(f"\n1. Breaking Point Analysis (< 95% success rate):")
        print(f"   AWS:   {aws_breaking_point if aws_breaking_point else 'Not reached (>1000 users)'} concurrent users")
        print(f"   Local: {local_breaking_point if local_breaking_point else 'Not reached (>1000 users)'} concurrent users")
        
        # Save results
        self._save_results()
        
        print("\n" + "="*70)
        print("Test complete! Results saved to stress_test_results.json")
        print("="*70 + "\n")
    
    def _save_results(self):
        """Save results to JSON file"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'stress_test_results_{timestamp}.json'
        
        with open(filename, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\nDetailed results saved to: {filename}")


async def main():
    """Main execution function"""
    print("\n" + "="*70)
    print("CONFIGURATION")
    print("="*70)
    print(f"SageMaker Endpoint: {SAGEMAKER_ENDPOINT_NAME}")
    print(f"Local Endpoint:     {LOCAL_ENDPOINT}")
    print(f"AWS Region:         {AWS_REGION}")
    print(f"Test Images Folder: {TEST_IMAGES_FOLDER}")
    print(f"Test Levels:        {', '.join(map(str, [400, 500, 600, 700, 800, 900, 1000]))} concurrent users")
    print("="*70)
    
    # Configuration prompt
    response = input("\nReady to start tests? (yes/no): ").strip().lower()
    if response != 'yes':
        print("Test cancelled.")
        return
    
    test_aws = input("Test AWS SageMaker? (yes/no): ").strip().lower() == 'yes'
    test_local = input("Test Local Server? (yes/no): ").strip().lower() == 'yes'
    
    if not test_aws and not test_local:
        print("No tests selected. Exiting.")
        return
    
    # Run tests
    tester = ComprehensiveStressTest()
    await tester.run_all_tests(test_aws=test_aws, test_local=test_local)


if __name__ == "__main__":
    # Run the async main function
    asyncio.run(main())
