"""
Improved Dual Stress Test: AWS vs Local
- Proper AWS authentication using boto3
- Gradual ramp-up to avoid overwhelming systems
- Better error handling and metrics
"""

import asyncio
import aiohttp
import boto3
import time
import json
import random
import statistics
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import concurrent.futures

class ImprovedStressTest:
    """Stress test with gradual ramp-up and proper authentication"""
    
    def __init__(self, endpoint_name, local_url, test_folder, 
                 total_requests=1000, concurrent_users=50):
        self.endpoint_name = endpoint_name
        self.local_url = local_url
        self.test_folder = Path(test_folder)
        self.total_requests = total_requests
        self.concurrent_users = concurrent_users
        
        # AWS client
        self.sagemaker_runtime = boto3.client('sagemaker-runtime', region_name='us-east-2')
        
        # Find test images
        self.test_images = list(self.test_folder.glob('**/*.png'))
        print(f"Found {len(self.test_images)} test spectrograms")
        
        if not self.test_images:
            raise ValueError(f"No PNG files found in {test_folder}")
        
        # Results
        self.aws_results = []
        self.local_results = []
        self.aws_errors = []
        self.local_errors = []
        
        self.start_time = None
    
    def test_aws_endpoint(self, image_path):
        """Test AWS endpoint with proper authentication"""
        start_time = time.time()
        
        try:
            # Read image
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            # Call SageMaker - measure inference time
            inference_start = time.time()
            response = self.sagemaker_runtime.invoke_endpoint(
                EndpointName=self.endpoint_name,
                ContentType='image/png',
                Body=image_data
            )
            
            # Parse response
            result = json.loads(response['Body'].read().decode())
            inference_time = time.time() - inference_start  # Total time including network + inference
            response_time = time.time() - start_time
            
            return {
                'endpoint': 'AWS',
                'image': image_path.name,
                'timestamp': time.time(),
                'success': True,
                'response_time': response_time,
                'inference_time': inference_time,
                'predicted_class': result.get('predicted_class'),
                'confidence': result.get('confidence'),
                'status_code': response['ResponseMetadata']['HTTPStatusCode']
            }, None
            
        except Exception as e:
            return None, {
                'endpoint': 'AWS',
                'image': image_path.name,
                'error': str(e),
                'response_time': time.time() - start_time
            }
    
    async def test_local_endpoint(self, session, image_path):
        """Test local endpoint"""
        start_time = time.time()
        
        try:
            # Read image
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            # Call local server
            async with session.post(
                self.local_url,
                data=image_data,
                headers={'Content-Type': 'image/png'},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                
                response_time = time.time() - start_time
                response_data = await response.json()
                
                return {
                    'endpoint': 'Local',
                    'image': image_path.name,
                    'timestamp': time.time(),
                    'success': response.status == 200,
                    'response_time': response_time,
                    'inference_time': response_data.get('inference_time_ms', 0) / 1000,
                    'predicted_class': response_data.get('predicted_class'),
                    'confidence': response_data.get('confidence'),
                    'status_code': response.status,
                    'system_metrics': response_data.get('system_metrics', {})
                }, None
                
        except Exception as e:
            return None, {
                'endpoint': 'Local',
                'image': image_path.name,
                'error': str(e),
                'response_time': time.time() - start_time
            }
    
    async def run_batch(self, images_batch, executor):
        """Run a batch of tests on both endpoints"""
        async with aiohttp.ClientSession() as session:
            for image in images_batch:
                # Test AWS (in thread pool since it's synchronous)
                aws_future = executor.submit(self.test_aws_endpoint, image)
                
                # Test Local (async)
                local_task = self.test_local_endpoint(session, image)
                
                # Wait for both
                aws_result, aws_error = await asyncio.get_event_loop().run_in_executor(
                    None, aws_future.result
                )
                local_result, local_error = await local_task
                
                # Store results
                if aws_result:
                    self.aws_results.append(aws_result)
                if aws_error:
                    self.aws_errors.append(aws_error)
                
                if local_result:
                    self.local_results.append(local_result)
                if local_error:
                    self.local_errors.append(local_error)
    
    async def run_test(self):
        """Execute stress test with gradual ramp-up"""
        print(f"\n{'='*80}")
        print(f"IMPROVED STRESS TEST: AWS vs LOCAL")
        print(f"{'='*80}")
        print(f"AWS Endpoint:     {self.endpoint_name}")
        print(f"Local Endpoint:   {self.local_url}")
        print(f"Test Images:      {len(self.test_images)}")
        print(f"Total Requests:   {self.total_requests}")
        print(f"Concurrent Users: {self.concurrent_users}")
        print(f"{'='*80}\n")
        
        self.start_time = time.time()
        
        # Create random test sequence
        test_sequence = [random.choice(self.test_images) for _ in range(self.total_requests)]
        
        # Split into batches for gradual ramp-up
        batch_size = self.concurrent_users
        batches = [test_sequence[i:i + batch_size] for i in range(0, len(test_sequence), batch_size)]
        
        # Thread pool for AWS calls
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.concurrent_users)
        
        try:
            # Run batches
            for i, batch in enumerate(batches):
                print(f"Processing batch {i+1}/{len(batches)} ({len(batch)} requests)...")
                await self.run_batch(batch, executor)
                
                # Progress update
                total_completed = len(self.aws_results) + len(self.local_results)
                aws_success = len(self.aws_results)
                local_success = len(self.local_results)
                print(f"  AWS: {aws_success} success, {len(self.aws_errors)} errors | "
                      f"Local: {local_success} success, {len(self.local_errors)} errors")
                
                # Small delay between batches to avoid overwhelming systems
                if i < len(batches) - 1:
                    await asyncio.sleep(0.5)
        
        finally:
            executor.shutdown(wait=True)
        
        # Generate report
        self.generate_report()
    
    def calculate_metrics(self, results, endpoint_name):
        """Calculate comprehensive metrics"""
        if not results:
            return None
        
        response_times = [r['response_time'] for r in results]
        inference_times = [r.get('inference_time', 0) for r in results if r.get('inference_time')]
        confidences = [r['confidence'] for r in results if r.get('confidence')]
        
        # System metrics (local only)
        cpu_usage = []
        memory_mb = []
        if 'system_metrics' in results[0]:
            cpu_usage = [r['system_metrics'].get('cpu_usage_percent', 0) 
                        for r in results if 'system_metrics' in r]
            memory_mb = [r['system_metrics'].get('memory_mb', 0) 
                        for r in results if 'system_metrics' in r]
        
        metrics = {
            'endpoint': endpoint_name,
            'total_requests': len(results),
            'response_time': {
                'min': min(response_times),
                'max': max(response_times),
                'mean': statistics.mean(response_times),
                'median': statistics.median(response_times),
                'std': statistics.stdev(response_times) if len(response_times) > 1 else 0,
                'p95': sorted(response_times)[int(len(response_times) * 0.95)],
                'p99': sorted(response_times)[int(len(response_times) * 0.99)]
            },
            'throughput': len(results) / (time.time() - self.start_time)
        }
        
        if inference_times:
            metrics['inference_time'] = {
                'min': min(inference_times),
                'max': max(inference_times),
                'mean': statistics.mean(inference_times),
                'median': statistics.median(inference_times)
            }
        
        if confidences:
            metrics['confidence'] = {
                'min': min(confidences),
                'max': max(confidences),
                'mean': statistics.mean(confidences),
                'median': statistics.median(confidences)
            }
        
        if cpu_usage:
            metrics['system'] = {
                'cpu_mean': statistics.mean(cpu_usage),
                'cpu_max': max(cpu_usage),
                'memory_mean_mb': statistics.mean(memory_mb),
                'memory_max_mb': max(memory_mb)
            }
        
        return metrics
    
    def generate_report(self):
        """Generate detailed comparison report"""
        print(f"\n{'='*80}")
        print(f"STRESS TEST RESULTS")
        print(f"{'='*80}")
        
        test_duration = time.time() - self.start_time
        print(f"\nTest Duration: {test_duration:.2f} seconds")
        print(f"Target Requests: {self.total_requests}")
        print(f"Actual Completed: {len(self.aws_results) + len(self.local_results)}")
        
        # AWS Metrics
        print(f"\n{'-AWS SAGEMAKER ENDPOINT':-^80}")
        aws_metrics = self.calculate_metrics(self.aws_results, 'AWS')
        if aws_metrics:
            self.print_metrics(aws_metrics)
        print(f"Errors: {len(self.aws_errors)}")
        if self.aws_errors[:3]:
            print("Sample errors:", [e['error'][:50] for e in self.aws_errors[:3]])
        
        # Local Metrics
        print(f"\n{'-LOCAL MODEL ENDPOINT':-^80}")
        local_metrics = self.calculate_metrics(self.local_results, 'Local')
        if local_metrics:
            self.print_metrics(local_metrics)
        print(f"Errors: {len(self.local_errors)}")
        if self.local_errors[:3]:
            print("Sample errors:", [e['error'][:50] for e in self.local_errors[:3]])
        
        # Comparison
        if aws_metrics and local_metrics:
            print(f"\n{'-COMPARISON (AWS vs Local)':-^80}")
            self.print_comparison(aws_metrics, local_metrics)
        
        # Save results
        output = {
            'test_config': {
                'endpoint': self.endpoint_name,
                'local_url': self.local_url,
                'total_requests': self.total_requests,
                'concurrent_users': self.concurrent_users,
                'test_duration': test_duration
            },
            'aws': aws_metrics,
            'local': local_metrics,
            'aws_errors': self.aws_errors[:100],  # Save first 100
            'local_errors': self.local_errors[:100]
        }
        
        filename = f"stress_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(output, f, indent=2)
        
        print(f"\n{'='*80}")
        print(f"Results saved to: {filename}")
        print(f"{'='*80}\n")
    
    def print_metrics(self, m):
        """Print formatted metrics"""
        print(f"\nSuccess Rate: {m['total_requests']}/{m['total_requests']} (100.0%)")
        print(f"Throughput: {m['throughput']:.2f} requests/sec")
        
        print(f"\nResponse Time (seconds):")
        print(f"  Min:    {m['response_time']['min']:.3f}")
        print(f"  Mean:   {m['response_time']['mean']:.3f}")
        print(f"  Median: {m['response_time']['median']:.3f}")
        print(f"  Max:    {m['response_time']['max']:.3f}")
        print(f"  P95:    {m['response_time']['p95']:.3f}")
        print(f"  P99:    {m['response_time']['p99']:.3f}")
        print(f"  StdDev: {m['response_time']['std']:.3f}")
        
        if 'inference_time' in m:
            print(f"\nInference Time (seconds):")
            print(f"  Min:    {m['inference_time']['min']:.3f}")
            print(f"  Mean:   {m['inference_time']['mean']:.3f}")
            print(f"  Median: {m['inference_time']['median']:.3f}")
            print(f"  Max:    {m['inference_time']['max']:.3f}")
        
        if 'confidence' in m:
            print(f"\nConfidence:")
            print(f"  Min:    {m['confidence']['min']:.4f}")
            print(f"  Mean:   {m['confidence']['mean']:.4f}")
            print(f"  Median: {m['confidence']['median']:.4f}")
            print(f"  Max:    {m['confidence']['max']:.4f}")
        
        if 'system' in m:
            print(f"\nSystem Metrics:")
            print(f"  CPU Mean:    {m['system']['cpu_mean']:.1f}%")
            print(f"  CPU Max:     {m['system']['cpu_max']:.1f}%")
            print(f"  Memory Mean: {m['system']['memory_mean_mb']:.1f} MB")
            print(f"  Memory Max:  {m['system']['memory_max_mb']:.1f} MB")
    
    def print_comparison(self, aws, local):
        """Print side-by-side comparison"""
        def pct_diff(aws_val, local_val):
            if aws_val == 0:
                return "N/A"
            diff = ((local_val - aws_val) / aws_val) * 100
            sign = "+" if diff > 0 else ""
            return f"{sign}{diff:.1f}%"
        
        print(f"\n{'Metric':<35} {'AWS':>12} {'Local':>12} {'Difference':>15}")
        print(f"{'-'*75}")
        
        print(f"{'Throughput (req/s)':<35} {aws['throughput']:>12.2f} {local['throughput']:>12.2f} "
              f"{pct_diff(aws['throughput'], local['throughput']):>15}")
        
        print(f"{'Mean Response Time (s)':<35} {aws['response_time']['mean']:>12.3f} "
              f"{local['response_time']['mean']:>12.3f} "
              f"{pct_diff(aws['response_time']['mean'], local['response_time']['mean']):>15}")
        
        print(f"{'P95 Response Time (s)':<35} {aws['response_time']['p95']:>12.3f} "
              f"{local['response_time']['p95']:>12.3f} "
              f"{pct_diff(aws['response_time']['p95'], local['response_time']['p95']):>15}")
        
        # Both should have inference time now
        if 'inference_time' in aws and 'inference_time' in local:
            print(f"{'Mean Inference Time (s)':<35} {aws['inference_time']['mean']:>12.3f} "
                  f"{local['inference_time']['mean']:>12.3f} "
                  f"{pct_diff(aws['inference_time']['mean'], local['inference_time']['mean']):>15}")
            
            # Show which is faster
            if aws['inference_time']['mean'] < local['inference_time']['mean']:
                speedup = local['inference_time']['mean'] / aws['inference_time']['mean']
                print(f"\n>>> AWS inference is {speedup:.2f}x FASTER than Local")
            else:
                speedup = aws['inference_time']['mean'] / local['inference_time']['mean']
                print(f"\n>>> Local inference is {speedup:.2f}x FASTER than AWS")
        
        if 'confidence' in aws and 'confidence' in local:
            print(f"\n{'Mean Confidence':<35} {aws['confidence']['mean']:>12.4f} "
                  f"{local['confidence']['mean']:>12.4f} "
                  f"{pct_diff(aws['confidence']['mean'], local['confidence']['mean']):>15}")
        
        # Show system load for local
        if 'system' in local:
            print(f"\n{'--- LOCAL SYSTEM LOAD ---':<35}")
            print(f"{'CPU Usage (mean)':<35} {'N/A':>12} {local['system']['cpu_mean']:>11.1f}%")
            print(f"{'CPU Usage (max)':<35} {'N/A':>12} {local['system']['cpu_max']:>11.1f}%")
            print(f"{'Memory (mean)':<35} {'N/A':>12} {local['system']['memory_mean_mb']:>9.0f} MB")
            print(f"{'Memory (max)':<35} {'N/A':>12} {local['system']['memory_max_mb']:>9.0f} MB")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--endpoint', default='urbansound-classifier-v1',
                       help='AWS SageMaker endpoint name')
    parser.add_argument('--local-url', default='http://127.0.0.1:5000/invocations',
                       help='Local inference server URL')
    parser.add_argument('--test-folder', required=True,
                       help='Folder with test spectrograms')
    parser.add_argument('--requests', type=int, default=1000,
                       help='Total number of requests')
    parser.add_argument('--concurrent', type=int, default=50,
                       help='Concurrent users (batch size)')
    
    args = parser.parse_args()
    
    tester = ImprovedStressTest(
        endpoint_name=args.endpoint,
        local_url=args.local_url,
        test_folder=args.test_folder,
        total_requests=args.requests,
        concurrent_users=args.concurrent
    )
    
    asyncio.run(tester.run_test())


if __name__ == "__main__":
    main()
