"""
Dual Load Test: AWS vs Local Model Comparison
Tests both deployments simultaneously with the same data
"""

import asyncio
import aiohttp
import time
import json
import psutil
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import statistics

class DualLoadTester:
    """Test AWS and Local models simultaneously"""
    
    def __init__(self, aws_url, local_url, test_folder, num_requests=1000):
        self.aws_url = aws_url
        self.local_url = local_url
        self.test_folder = Path(test_folder)
        self.num_requests = num_requests
        
        # Find test spectrograms (fold10) - search recursively for class subfolders
        self.test_images = list(self.test_folder.glob('**/*.png'))
        print(f"Found {len(self.test_images)} test spectrograms")
        
        if not self.test_images:
            raise ValueError(f"No PNG files found in {test_folder}")
        
        # Results storage
        self.aws_results = []
        self.local_results = []
        self.aws_errors = []
        self.local_errors = []
        
        self.start_time = None
        
    async def test_endpoint(self, session, image_path, endpoint_url, endpoint_name):
        """Test a single endpoint"""
        start_time = time.time()
        
        try:
            # Read image
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            # Send request
            async with session.post(
                endpoint_url,
                data=image_data,
                headers={'Content-Type': 'image/png'},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                
                response_time = time.time() - start_time
                response_data = await response.json()
                
                result = {
                    'endpoint': endpoint_name,
                    'image': image_path.name,
                    'timestamp': time.time(),
                    'status': response.status,
                    'response_time': response_time,
                    'success': response.status == 200,
                    'predicted_class': response_data.get('predicted_class'),
                    'confidence': response_data.get('confidence'),
                    'inference_time_ms': response_data.get('inference_time_ms', 0),
                    'system_metrics': response_data.get('system_metrics', {})
                }
                
                return result, None
                
        except Exception as e:
            error = {
                'endpoint': endpoint_name,
                'image': image_path.name,
                'timestamp': time.time(),
                'error': str(e),
                'response_time': time.time() - start_time
            }
            return None, error
    
    async def test_both_endpoints(self, session, image_path, request_num):
        """Test both AWS and Local endpoints with same image"""
        
        # Test both simultaneously
        aws_task = self.test_endpoint(session, image_path, self.aws_url, 'AWS')
        local_task = self.test_endpoint(session, image_path, self.local_url, 'Local')
        
        results = await asyncio.gather(aws_task, local_task, return_exceptions=True)
        
        # Process AWS result
        aws_result, aws_error = results[0] if not isinstance(results[0], Exception) else (None, {'error': str(results[0])})
        if aws_result:
            self.aws_results.append(aws_result)
        if aws_error:
            self.aws_errors.append(aws_error)
        
        # Process Local result
        local_result, local_error = results[1] if not isinstance(results[1], Exception) else (None, {'error': str(results[1])})
        if local_result:
            self.local_results.append(local_result)
        if local_error:
            self.local_errors.append(local_error)
        
        # Print progress
        if request_num % 50 == 0:
            print(f"Progress: {request_num}/{self.num_requests} | "
                  f"AWS: {len(self.aws_results)} success, {len(self.aws_errors)} errors | "
                  f"Local: {len(self.local_results)} success, {len(self.local_errors)} errors")
    
    async def run_test(self):
        """Execute the load test"""
        print(f"\n{'='*80}")
        print(f"DUAL LOAD TEST: AWS vs LOCAL")
        print(f"{'='*80}")
        print(f"AWS Endpoint:   {self.aws_url}")
        print(f"Local Endpoint: {self.local_url}")
        print(f"Test Images:    {len(self.test_images)}")
        print(f"Requests:       {self.num_requests}")
        print(f"{'='*80}\n")
        
        self.start_time = time.time()
        
        # Prepare test sequence
        import random
        test_sequence = [random.choice(self.test_images) for _ in range(self.num_requests)]
        
        # Run tests
        connector = aiohttp.TCPConnector(limit=100)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = [
                self.test_both_endpoints(session, img, i) 
                for i, img in enumerate(test_sequence, 1)
            ]
            await asyncio.gather(*tasks)
        
        # Generate report
        self.generate_report()
    
    def calculate_metrics(self, results, endpoint_name):
        """Calculate metrics for one endpoint"""
        if not results:
            return None
        
        response_times = [r['response_time'] for r in results]
        inference_times = [r.get('inference_time_ms', 0) / 1000 for r in results]
        confidences = [r['confidence'] for r in results if r.get('confidence')]
        
        # Get system metrics (for local only)
        cpu_usage = [r['system_metrics'].get('cpu_usage_percent', 0) 
                     for r in results if 'system_metrics' in r]
        memory_mb = [r['system_metrics'].get('memory_mb', 0) 
                     for r in results if 'system_metrics' in r]
        
        metrics = {
            'endpoint': endpoint_name,
            'total_requests': len(results),
            'successful_requests': len(results),
            'response_time': {
                'min': min(response_times),
                'max': max(response_times),
                'mean': statistics.mean(response_times),
                'median': statistics.median(response_times),
                'std': statistics.stdev(response_times) if len(response_times) > 1 else 0,
                'p95': sorted(response_times)[int(len(response_times) * 0.95)],
                'p99': sorted(response_times)[int(len(response_times) * 0.99)]
            },
            'inference_time': {
                'min': min(inference_times),
                'max': max(inference_times),
                'mean': statistics.mean(inference_times),
                'median': statistics.median(inference_times)
            },
            'confidence': {
                'min': min(confidences) if confidences else 0,
                'max': max(confidences) if confidences else 0,
                'mean': statistics.mean(confidences) if confidences else 0
            },
            'throughput': len(results) / (time.time() - self.start_time)
        }
        
        if cpu_usage:
            metrics['system'] = {
                'cpu_mean': statistics.mean(cpu_usage),
                'cpu_max': max(cpu_usage),
                'memory_mean_mb': statistics.mean(memory_mb),
                'memory_max_mb': max(memory_mb)
            }
        
        return metrics
    
    def generate_report(self):
        """Generate comparison report"""
        print(f"\n{'='*80}")
        print(f"LOAD TEST RESULTS")
        print(f"{'='*80}")
        
        test_duration = time.time() - self.start_time
        print(f"\nTest Duration: {test_duration:.2f} seconds")
        print(f"Total Requests: {self.num_requests}")
        
        # AWS Metrics
        print(f"\n{'AWS SAGEMAKER ENDPOINT':-^80}")
        aws_metrics = self.calculate_metrics(self.aws_results, 'AWS')
        if aws_metrics:
            self.print_metrics(aws_metrics)
        print(f"Errors: {len(self.aws_errors)}")
        
        # Local Metrics  
        print(f"\n{'LOCAL MODEL ENDPOINT':-^80}")
        local_metrics = self.calculate_metrics(self.local_results, 'Local')
        if local_metrics:
            self.print_metrics(local_metrics)
        print(f"Errors: {len(self.local_errors)}")
        
        # Comparison
        if aws_metrics and local_metrics:
            print(f"\n{'COMPARISON (AWS vs Local)':-^80}")
            self.print_comparison(aws_metrics, local_metrics)
        
        # Save results
        output = {
            'test_config': {
                'aws_url': self.aws_url,
                'local_url': self.local_url,
                'num_requests': self.num_requests,
                'test_duration': test_duration
            },
            'aws': aws_metrics,
            'local': local_metrics,
            'aws_errors': self.aws_errors,
            'local_errors': self.local_errors
        }
        
        filename = f"dual_load_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(output, f, indent=2)
        
        print(f"\n{'='*80}")
        print(f"Results saved to: {filename}")
        print(f"{'='*80}\n")
    
    def print_metrics(self, m):
        """Print metrics in formatted way"""
        print(f"\nSuccess Rate: {m['successful_requests']}/{m['total_requests']} "
              f"({m['successful_requests']/m['total_requests']*100:.1f}%)")
        print(f"Throughput: {m['throughput']:.2f} requests/sec")
        
        print(f"\nResponse Time (seconds):")
        print(f"  Min:    {m['response_time']['min']:.3f}")
        print(f"  Mean:   {m['response_time']['mean']:.3f}")
        print(f"  Median: {m['response_time']['median']:.3f}")
        print(f"  Max:    {m['response_time']['max']:.3f}")
        print(f"  P95:    {m['response_time']['p95']:.3f}")
        print(f"  P99:    {m['response_time']['p99']:.3f}")
        print(f"  StdDev: {m['response_time']['std']:.3f}")
        
        print(f"\nInference Time (seconds):")
        print(f"  Min:    {m['inference_time']['min']:.3f}")
        print(f"  Mean:   {m['inference_time']['mean']:.3f}")
        print(f"  Median: {m['inference_time']['median']:.3f}")
        print(f"  Max:    {m['inference_time']['max']:.3f}")
        
        print(f"\nConfidence:")
        print(f"  Min:  {m['confidence']['min']:.4f}")
        print(f"  Mean: {m['confidence']['mean']:.4f}")
        print(f"  Max:  {m['confidence']['max']:.4f}")
        
        if 'system' in m:
            print(f"\nSystem Metrics:")
            print(f"  CPU Mean:    {m['system']['cpu_mean']:.1f}%")
            print(f"  CPU Max:     {m['system']['cpu_max']:.1f}%")
            print(f"  Memory Mean: {m['system']['memory_mean_mb']:.1f} MB")
            print(f"  Memory Max:  {m['system']['memory_max_mb']:.1f} MB")
    
    def print_comparison(self, aws, local):
        """Print side-by-side comparison"""
        def pct_diff(aws_val, local_val):
            if aws_val == 0:
                return "N/A"
            diff = ((local_val - aws_val) / aws_val) * 100
            sign = "+" if diff > 0 else ""
            return f"{sign}{diff:.1f}%"
        
        print(f"\n{'Metric':<30} {'AWS':>12} {'Local':>12} {'Difference':>15}")
        print(f"{'-'*70}")
        
        print(f"{'Throughput (req/s)':<30} {aws['throughput']:>12.2f} {local['throughput']:>12.2f} "
              f"{pct_diff(aws['throughput'], local['throughput']):>15}")
        
        print(f"{'Mean Response Time (s)':<30} {aws['response_time']['mean']:>12.3f} "
              f"{local['response_time']['mean']:>12.3f} "
              f"{pct_diff(aws['response_time']['mean'], local['response_time']['mean']):>15}")
        
        print(f"{'P95 Response Time (s)':<30} {aws['response_time']['p95']:>12.3f} "
              f"{local['response_time']['p95']:>12.3f} "
              f"{pct_diff(aws['response_time']['p95'], local['response_time']['p95']):>15}")
        
        print(f"{'Mean Inference Time (s)':<30} {aws['inference_time']['mean']:>12.3f} "
              f"{local['inference_time']['mean']:>12.3f} "
              f"{pct_diff(aws['inference_time']['mean'], local['inference_time']['mean']):>15}")
        
        print(f"{'Mean Confidence':<30} {aws['confidence']['mean']:>12.4f} "
              f"{local['confidence']['mean']:>12.4f} "
              f"{pct_diff(aws['confidence']['mean'], local['confidence']['mean']):>15}")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--aws-url', required=True, 
                       help='AWS SageMaker endpoint URL')
    parser.add_argument('--local-url', default='http://127.0.0.1:5000/invocations',
                       help='Local inference server URL')
    parser.add_argument('--test-folder', required=True,
                       help='Folder with test spectrograms (fold10)')
    parser.add_argument('--requests', type=int, default=1000,
                       help='Number of requests to send')
    
    args = parser.parse_args()
    
    tester = DualLoadTester(
        aws_url=args.aws_url,
        local_url=args.local_url,
        test_folder=args.test_folder,
        num_requests=args.requests
    )
    
    asyncio.run(tester.run_test())


if __name__ == "__main__":
    main()
