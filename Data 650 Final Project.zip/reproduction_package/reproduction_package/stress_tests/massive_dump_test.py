"""
MASSIVE DUMP TEST - 2000 Concurrent Requests
All requests launched simultaneously to both endpoints
"""

import asyncio
import aiohttp
import boto3
import time
import json
import random
import statistics
from pathlib import Path
from datetime import datetime
import concurrent.futures

class MassiveDumpTest:
    """Single massive concurrent load test"""
    
    def __init__(self, endpoint_name, local_url, test_folder, num_requests=2000):
        self.endpoint_name = endpoint_name
        self.local_url = local_url
        self.test_folder = Path(test_folder)
        self.num_requests = num_requests
        
        # AWS client with no retries
        self.sagemaker_runtime = boto3.client(
            'sagemaker-runtime', 
            region_name='us-east-2',
            config=boto3.session.Config(
                read_timeout=120,
                connect_timeout=120,
                retries={'max_attempts': 0}
            )
        )
        
        # Find test images
        self.test_images = list(self.test_folder.glob('**/*.png'))
        print(f"Found {len(self.test_images)} test spectrograms")
        
        if not self.test_images:
            raise ValueError(f"No PNG files found in {test_folder}")
        
        # Results
        self.aws_results = {'success': [], 'errors': []}
        self.local_results = {'success': [], 'errors': []}
        
        self.start_time = None
    
    def test_aws_sync(self, image_path, request_id):
        """Test AWS endpoint (synchronous)"""
        start_time = time.time()
        
        try:
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            inference_start = time.time()
            response = self.sagemaker_runtime.invoke_endpoint(
                EndpointName=self.endpoint_name,
                ContentType='image/png',
                Body=image_data
            )
            
            result = json.loads(response['Body'].read().decode())
            inference_time = time.time() - inference_start
            
            return {
                'request_id': request_id,
                'endpoint': 'AWS',
                'image': image_path.name,
                'timestamp': time.time(),
                'response_time': time.time() - start_time,
                'inference_time': inference_time,
                'predicted_class': result.get('predicted_class'),
                'confidence': result.get('confidence'),
                'success': True
            }
            
        except Exception as e:
            return {
                'request_id': request_id,
                'endpoint': 'AWS',
                'image': image_path.name,
                'timestamp': time.time(),
                'response_time': time.time() - start_time,
                'error': str(e)[:200],  # Truncate long errors
                'success': False
            }
    
    async def test_local_async(self, session, image_path, request_id):
        """Test local endpoint (async)"""
        start_time = time.time()
        
        try:
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            async with session.post(
                self.local_url,
                data=image_data,
                headers={'Content-Type': 'image/png'},
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                
                response_data = await response.json()
                
                return {
                    'request_id': request_id,
                    'endpoint': 'Local',
                    'image': image_path.name,
                    'timestamp': time.time(),
                    'response_time': time.time() - start_time,
                    'inference_time': response_data.get('inference_time_ms', 0) / 1000,
                    'predicted_class': response_data.get('predicted_class'),
                    'confidence': response_data.get('confidence'),
                    'system_metrics': response_data.get('system_metrics', {}),
                    'success': response.status == 200
                }
                
        except Exception as e:
            return {
                'request_id': request_id,
                'endpoint': 'Local',
                'image': image_path.name,
                'timestamp': time.time(),
                'response_time': time.time() - start_time,
                'error': str(e)[:200],
                'success': False
            }
    
    async def run_massive_dump(self):
        """Launch all requests simultaneously"""
        print(f"\n{'='*80}")
        print(f"MASSIVE CONCURRENT DUMP TEST")
        print(f"{'='*80}")
        print(f"AWS Endpoint:    {self.endpoint_name}")
        print(f"Local Endpoint:  {self.local_url}")
        print(f"Total Requests:  {self.num_requests} to EACH endpoint")
        print(f"Strategy:        ALL requests launched simultaneously")
        print(f"{'='*80}\n")
        
        # Generate random test sequence
        test_images = [random.choice(self.test_images) for _ in range(self.num_requests)]
        
        print(f"Preparing to launch {self.num_requests * 2} total requests...")
        print(f"This will take a while...")
        
        self.start_time = time.time()
        
        # Thread pool for AWS (high concurrency)
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.num_requests)
        
        # Async connector for Local (high concurrency)
        connector = aiohttp.TCPConnector(limit=self.num_requests)
        
        try:
            async with aiohttp.ClientSession(connector=connector) as session:
                # Launch ALL AWS requests
                print(f"\n🚀 Launching {self.num_requests} AWS requests simultaneously...")
                aws_futures = [
                    executor.submit(self.test_aws_sync, img, i) 
                    for i, img in enumerate(test_images)
                ]
                
                # Launch ALL Local requests
                print(f"🚀 Launching {self.num_requests} Local requests simultaneously...")
                local_tasks = [
                    self.test_local_async(session, img, i) 
                    for i, img in enumerate(test_images)
                ]
                
                print(f"\n⏳ Waiting for all requests to complete...\n")
                
                # Progress tracking
                start = time.time()
                
                # Gather AWS results
                aws_results = await asyncio.gather(
                    *[asyncio.get_event_loop().run_in_executor(None, f.result) for f in aws_futures],
                    return_exceptions=True
                )
                
                # Gather Local results  
                local_results = await asyncio.gather(*local_tasks, return_exceptions=True)
                
                # Process results
                for result in aws_results:
                    if isinstance(result, Exception):
                        self.aws_results['errors'].append({'error': str(result)[:200]})
                    elif result['success']:
                        self.aws_results['success'].append(result)
                    else:
                        self.aws_results['errors'].append(result)
                
                for result in local_results:
                    if isinstance(result, Exception):
                        self.local_results['errors'].append({'error': str(result)[:200]})
                    elif result['success']:
                        self.local_results['success'].append(result)
                    else:
                        self.local_results['errors'].append(result)
        
        finally:
            executor.shutdown(wait=True)
        
        # Generate report
        self.generate_report()
    
    def calculate_metrics(self, results):
        """Calculate comprehensive metrics"""
        if not results:
            return None
        
        response_times = [r['response_time'] for r in results]
        inference_times = [r.get('inference_time', 0) for r in results if r.get('inference_time')]
        confidences = [r['confidence'] for r in results if r.get('confidence')]
        
        # Timeline analysis
        timestamps = [r['timestamp'] for r in results]
        first_response = min(timestamps) - self.start_time
        last_response = max(timestamps) - self.start_time
        
        metrics = {
            'total': len(results),
            'response_time': {
                'min': min(response_times),
                'max': max(response_times),
                'mean': statistics.mean(response_times),
                'median': statistics.median(response_times),
                'std': statistics.stdev(response_times) if len(response_times) > 1 else 0,
                'p95': sorted(response_times)[int(len(response_times) * 0.95)],
                'p99': sorted(response_times)[int(len(response_times) * 0.99)]
            },
            'timeline': {
                'first_response': first_response,
                'last_response': last_response,
                'completion_window': last_response - first_response
            },
            'throughput': len(results) / (max(timestamps) - min(timestamps)) if len(timestamps) > 1 else 0
        }
        
        if inference_times:
            metrics['inference_time'] = {
                'min': min(inference_times),
                'max': max(inference_times),
                'mean': statistics.mean(inference_times),
                'median': statistics.median(inference_times),
                'p95': sorted(inference_times)[int(len(inference_times) * 0.95)]
            }
        
        if confidences:
            metrics['confidence'] = {
                'min': min(confidences),
                'max': max(confidences),
                'mean': statistics.mean(confidences),
                'median': statistics.median(confidences)
            }
        
        # System metrics (local only)
        if results and 'system_metrics' in results[0]:
            cpu_usage = [r['system_metrics'].get('cpu_usage_percent', 0) for r in results]
            memory_mb = [r['system_metrics'].get('memory_mb', 0) for r in results]
            
            if cpu_usage:
                metrics['system'] = {
                    'cpu_mean': statistics.mean(cpu_usage),
                    'cpu_max': max(cpu_usage),
                    'memory_mean_mb': statistics.mean(memory_mb),
                    'memory_max_mb': max(memory_mb)
                }
        
        return metrics
    
    def generate_report(self):
        """Generate detailed report"""
        print(f"\n{'='*80}")
        print(f"MASSIVE DUMP TEST RESULTS")
        print(f"{'='*80}")
        
        total_duration = time.time() - self.start_time
        
        print(f"\nTest Duration: {total_duration:.2f} seconds")
        print(f"Total Requests: {self.num_requests * 2} ({self.num_requests} to each endpoint)")
        
        # AWS Results
        print(f"\n{'-AWS SAGEMAKER ENDPOINT':-^80}")
        aws_success_count = len(self.aws_results['success'])
        aws_error_count = len(self.aws_results['errors'])
        aws_success_rate = (aws_success_count / self.num_requests) * 100
        
        print(f"\nSuccess Rate: {aws_success_count}/{self.num_requests} ({aws_success_rate:.1f}%)")
        print(f"Errors: {aws_error_count} ({(aws_error_count/self.num_requests)*100:.1f}%)")
        
        aws_metrics = self.calculate_metrics(self.aws_results['success'])
        if aws_metrics:
            print(f"\nResponse Time (seconds):")
            print(f"  Min:    {aws_metrics['response_time']['min']:.3f}")
            print(f"  Mean:   {aws_metrics['response_time']['mean']:.3f}")
            print(f"  Median: {aws_metrics['response_time']['median']:.3f}")
            print(f"  P95:    {aws_metrics['response_time']['p95']:.3f}")
            print(f"  P99:    {aws_metrics['response_time']['p99']:.3f}")
            print(f"  Max:    {aws_metrics['response_time']['max']:.3f}")
            
            if 'inference_time' in aws_metrics:
                print(f"\nInference Time (seconds):")
                print(f"  Min:    {aws_metrics['inference_time']['min']:.3f}")
                print(f"  Mean:   {aws_metrics['inference_time']['mean']:.3f}")
                print(f"  Median: {aws_metrics['inference_time']['median']:.3f}")
                print(f"  P95:    {aws_metrics['inference_time']['p95']:.3f}")
                print(f"  Max:    {aws_metrics['inference_time']['max']:.3f}")
            
            print(f"\nTimeline:")
            print(f"  First response:  {aws_metrics['timeline']['first_response']:.2f}s after start")
            print(f"  Last response:   {aws_metrics['timeline']['last_response']:.2f}s after start")
            print(f"  Completion span: {aws_metrics['timeline']['completion_window']:.2f}s")
            print(f"  Throughput:      {aws_metrics['throughput']:.2f} req/s")
            
            if 'confidence' in aws_metrics:
                print(f"\nConfidence:")
                print(f"  Mean:   {aws_metrics['confidence']['mean']:.4f}")
                print(f"  Median: {aws_metrics['confidence']['median']:.4f}")
        
        if aws_error_count > 0:
            print(f"\nSample Errors (first 5):")
            for i, error in enumerate(self.aws_results['errors'][:5]):
                print(f"  {i+1}. {error.get('error', 'Unknown error')[:80]}")
        
        # Local Results
        print(f"\n{'-LOCAL MODEL ENDPOINT':-^80}")
        local_success_count = len(self.local_results['success'])
        local_error_count = len(self.local_results['errors'])
        local_success_rate = (local_success_count / self.num_requests) * 100
        
        print(f"\nSuccess Rate: {local_success_count}/{self.num_requests} ({local_success_rate:.1f}%)")
        print(f"Errors: {local_error_count} ({(local_error_count/self.num_requests)*100:.1f}%)")
        
        local_metrics = self.calculate_metrics(self.local_results['success'])
        if local_metrics:
            print(f"\nResponse Time (seconds):")
            print(f"  Min:    {local_metrics['response_time']['min']:.3f}")
            print(f"  Mean:   {local_metrics['response_time']['mean']:.3f}")
            print(f"  Median: {local_metrics['response_time']['median']:.3f}")
            print(f"  P95:    {local_metrics['response_time']['p95']:.3f}")
            print(f"  P99:    {local_metrics['response_time']['p99']:.3f}")
            print(f"  Max:    {local_metrics['response_time']['max']:.3f}")
            
            if 'inference_time' in local_metrics:
                print(f"\nInference Time (seconds):")
                print(f"  Min:    {local_metrics['inference_time']['min']:.3f}")
                print(f"  Mean:   {local_metrics['inference_time']['mean']:.3f}")
                print(f"  Median: {local_metrics['inference_time']['median']:.3f}")
                print(f"  P95:    {local_metrics['inference_time']['p95']:.3f}")
                print(f"  Max:    {local_metrics['inference_time']['max']:.3f}")
            
            print(f"\nTimeline:")
            print(f"  First response:  {local_metrics['timeline']['first_response']:.2f}s after start")
            print(f"  Last response:   {local_metrics['timeline']['last_response']:.2f}s after start")
            print(f"  Completion span: {local_metrics['timeline']['completion_window']:.2f}s")
            print(f"  Throughput:      {local_metrics['throughput']:.2f} req/s")
            
            if 'confidence' in local_metrics:
                print(f"\nConfidence:")
                print(f"  Mean:   {local_metrics['confidence']['mean']:.4f}")
                print(f"  Median: {local_metrics['confidence']['median']:.4f}")
            
            if 'system' in local_metrics:
                print(f"\nSystem Metrics:")
                print(f"  CPU Mean:    {local_metrics['system']['cpu_mean']:.1f}%")
                print(f"  CPU Max:     {local_metrics['system']['cpu_max']:.1f}%")
                print(f"  Memory Mean: {local_metrics['system']['memory_mean_mb']:.1f} MB")
                print(f"  Memory Max:  {local_metrics['system']['memory_max_mb']:.1f} MB")
        
        if local_error_count > 0:
            print(f"\nSample Errors (first 5):")
            for i, error in enumerate(self.local_results['errors'][:5]):
                print(f"  {i+1}. {error.get('error', 'Unknown error')[:80]}")
        
        # Comparison
        if aws_metrics and local_metrics:
            print(f"\n{'-DIRECT COMPARISON':-^80}")
            
            print(f"\n{'Metric':<30} {'AWS':>15} {'Local':>15} {'Winner':>15}")
            print(f"{'-'*75}")
            
            # Success rate
            if aws_success_rate > local_success_rate:
                winner = "AWS"
                diff = aws_success_rate - local_success_rate
            else:
                winner = "Local"
                diff = local_success_rate - aws_success_rate
            print(f"{'Success Rate':<30} {aws_success_rate:>14.1f}% {local_success_rate:>14.1f}% {winner+' +'+str(round(diff,1))+'%':>15}")
            
            # Response time (lower is better)
            if aws_metrics['response_time']['mean'] < local_metrics['response_time']['mean']:
                winner = "AWS"
                speedup = local_metrics['response_time']['mean'] / aws_metrics['response_time']['mean']
            else:
                winner = "Local"
                speedup = aws_metrics['response_time']['mean'] / local_metrics['response_time']['mean']
            print(f"{'Avg Response Time':<30} {aws_metrics['response_time']['mean']:>13.3f}s {local_metrics['response_time']['mean']:>13.3f}s {winner+' '+str(round(speedup,2))+'x':>15}")
            
            # Inference time (if both have it)
            if 'inference_time' in aws_metrics and 'inference_time' in local_metrics:
                if aws_metrics['inference_time']['mean'] < local_metrics['inference_time']['mean']:
                    winner = "AWS"
                    speedup = local_metrics['inference_time']['mean'] / aws_metrics['inference_time']['mean']
                else:
                    winner = "Local"
                    speedup = aws_metrics['inference_time']['mean'] / local_metrics['inference_time']['mean']
                print(f"{'Avg Inference Time':<30} {aws_metrics['inference_time']['mean']:>13.3f}s {local_metrics['inference_time']['mean']:>13.3f}s {winner+' '+str(round(speedup,2))+'x':>15}")
            
            # Throughput (higher is better)
            if aws_metrics['throughput'] > local_metrics['throughput']:
                winner = "AWS"
                ratio = aws_metrics['throughput'] / local_metrics['throughput']
            else:
                winner = "Local"
                ratio = local_metrics['throughput'] / aws_metrics['throughput']
            print(f"{'Throughput':<30} {aws_metrics['throughput']:>12.2f}/s {local_metrics['throughput']:>12.2f}/s {winner+' '+str(round(ratio,2))+'x':>15}")
        
        # Save results
        output = {
            'test_config': {
                'endpoint': self.endpoint_name,
                'local_url': self.local_url,
                'num_requests': self.num_requests,
                'test_duration': total_duration
            },
            'aws': {
                'success_count': aws_success_count,
                'error_count': aws_error_count,
                'success_rate': aws_success_rate,
                'metrics': aws_metrics
            },
            'local': {
                'success_count': local_success_count,
                'error_count': local_error_count,
                'success_rate': local_success_rate,
                'metrics': local_metrics
            }
        }
        
        filename = f"massive_dump_{self.num_requests}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(output, f, indent=2)
        
        print(f"\n{'='*80}")
        print(f"Results saved to: {filename}")
        print(f"{'='*80}\n")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--endpoint', default='urbansound-classifier-v1')
    parser.add_argument('--local-url', default='http://127.0.0.1:5000/invocations')
    parser.add_argument('--test-folder', required=True)
    parser.add_argument('--requests', type=int, default=2000,
                       help='Number of concurrent requests to each endpoint')
    
    args = parser.parse_args()
    
    tester = MassiveDumpTest(
        endpoint_name=args.endpoint,
        local_url=args.local_url,
        test_folder=args.test_folder,
        num_requests=args.requests
    )
    
    asyncio.run(tester.run_massive_dump())


if __name__ == "__main__":
    main()
