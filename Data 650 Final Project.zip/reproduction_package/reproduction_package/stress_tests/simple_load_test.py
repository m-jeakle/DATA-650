#!/usr/bin/env python3
"""
Simplified UrbanSound8K Load Tester
Uses pre-generated spectrograms for faster testing
"""

import asyncio
import aiohttp
import time
import json
import random
from pathlib import Path
from datetime import datetime
from collections import defaultdict


class SimplifiedLoadTester:
    """Simplified load tester using existing spectrogram images"""
    
    def __init__(self, api_url, num_users=1000, ramp_up=60, duration=300):
        self.api_url = api_url
        self.num_users = num_users
        self.ramp_up_time = ramp_up
        self.test_duration = duration
        
        # Find all available spectrogram images
        self.test_images = list(Path('/mnt/user-data/uploads').glob('*_image.png'))
        print(f"Found {len(self.test_images)} spectrogram images for testing")
        
        if not self.test_images:
            raise ValueError("No test images found! Need spectrograms in /mnt/user-data/uploads/")
        
        # Metrics
        self.results = []
        self.errors = []
        self.start_time = None
        
        self.requests_sent = 0
        self.requests_completed = 0
        self.requests_failed = 0
    
    async def send_request(self, session, user_id):
        """Send a single prediction request"""
        request_start = time.time()
        
        try:
            # Pick a random spectrogram
            image_path = random.choice(self.test_images)
            
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            # Create form data
            data = aiohttp.FormData()
            data.add_field('file', image_data, 
                          filename=f'user{user_id}_audio.png',
                          content_type='image/png')
            
            # Send request
            async with session.post(self.api_url, data=data, 
                                  timeout=aiohttp.ClientTimeout(total=30)) as response:
                response_time = time.time() - request_start
                
                try:
                    response_data = await response.json()
                except:
                    response_data = await response.text()
                
                result = {
                    'user_id': user_id,
                    'timestamp': time.time(),
                    'status': response.status,
                    'response_time': response_time,
                    'success': response.status == 200,
                    'response_data': response_data
                }
                
                self.results.append(result)
                self.requests_completed += 1
                return result
                
        except asyncio.TimeoutError:
            error = {
                'user_id': user_id,
                'timestamp': time.time(),
                'error': 'Timeout',
                'response_time': time.time() - request_start
            }
            self.errors.append(error)
            self.requests_failed += 1
            return error
            
        except Exception as e:
            error = {
                'user_id': user_id,
                'timestamp': time.time(),
                'error': str(e),
                'response_time': time.time() - request_start
            }
            self.errors.append(error)
            self.requests_failed += 1
            return error
    
    async def user_session(self, session, user_id):
        """Simulate one user's activity"""
        # Stagger start times
        delay = (self.ramp_up_time / self.num_users) * user_id
        await asyncio.sleep(delay)
        
        session_start = time.time()
        
        while time.time() - session_start < (self.test_duration - delay):
            await self.send_request(session, user_id)
            self.requests_sent += 1
            
            # Think time: 2-8 seconds between requests
            await asyncio.sleep(random.uniform(2, 8))
    
    async def monitor(self):
        """Real-time monitoring"""
        try:
            while True:
                await asyncio.sleep(5)
                
                elapsed = time.time() - self.start_time
                success_rate = (self.requests_completed / self.requests_sent * 100) if self.requests_sent > 0 else 0
                throughput = self.requests_completed / elapsed if elapsed > 0 else 0
                
                # Calculate recent latency (last 100 requests)
                recent_results = self.results[-100:]
                avg_latency = sum(r['response_time'] for r in recent_results) / len(recent_results) if recent_results else 0
                
                print(f"\r[{int(elapsed)}s] Sent:{self.requests_sent} | "
                      f"Done:{self.requests_completed} | "
                      f"Fail:{self.requests_failed} | "
                      f"Success:{success_rate:.1f}% | "
                      f"RPS:{throughput:.1f} | "
                      f"Latency:{avg_latency:.2f}s", end='', flush=True)
        except asyncio.CancelledError:
            pass
    
    async def run(self):
        """Execute load test"""
        print(f"\n{'='*80}")
        print(f"URBANSOUND8K LOAD TEST")
        print(f"{'='*80}")
        print(f"API URL: {self.api_url}")
        print(f"Users: {self.num_users}")
        print(f"Ramp-up: {self.ramp_up_time}s")
        print(f"Duration: {self.test_duration}s")
        print(f"Test Images: {len(self.test_images)}")
        print(f"{'='*80}\n")
        
        self.start_time = time.time()
        
        # Start monitoring
        monitor_task = asyncio.create_task(self.monitor())
        
        # Run all users
        connector = aiohttp.TCPConnector(limit=self.num_users)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = [self.user_session(session, i) for i in range(self.num_users)]
            await asyncio.gather(*tasks)
        
        monitor_task.cancel()
        
        # Generate report
        self.report()
    
    def report(self):
        """Generate final report"""
        print("\n\n" + "="*80)
        print("LOAD TEST COMPLETE")
        print("="*80)
        
        total = len(self.results) + len(self.errors)
        success = len(self.results)
        failed = len(self.errors)
        success_rate = (success / total * 100) if total > 0 else 0
        
        print(f"\nOverall:")
        print(f"  Total Requests:  {total}")
        print(f"  Successful:      {success} ({success_rate:.2f}%)")
        print(f"  Failed:          {failed} ({100-success_rate:.2f}%)")
        
        if self.results:
            latencies = [r['response_time'] for r in self.results]
            latencies.sort()
            
            print(f"\nLatency (seconds):")
            print(f"  Min:     {min(latencies):.3f}")
            print(f"  Max:     {max(latencies):.3f}")
            print(f"  Mean:    {sum(latencies)/len(latencies):.3f}")
            print(f"  Median:  {latencies[len(latencies)//2]:.3f}")
            print(f"  P95:     {latencies[int(len(latencies)*0.95)]:.3f}")
            print(f"  P99:     {latencies[int(len(latencies)*0.99)]:.3f}")
        
        # Throughput
        test_duration = time.time() - self.start_time
        throughput = success / test_duration
        print(f"\nThroughput:")
        print(f"  Test Duration:   {test_duration:.1f}s")
        print(f"  Requests/sec:    {throughput:.2f}")
        
        # Errors
        if self.errors:
            print(f"\nErrors:")
            error_types = defaultdict(int)
            for e in self.errors:
                error_types[e.get('error', 'Unknown')] += 1
            for error_type, count in error_types.items():
                print(f"  {error_type}: {count}")
        
        # Save results
        output_file = f"load_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(output_file, 'w') as f:
            json.dump({
                'summary': {
                    'total': total,
                    'success': success,
                    'failed': failed,
                    'success_rate': success_rate,
                    'throughput': throughput,
                    'test_duration': test_duration
                },
                'results': self.results[:100],  # Save first 100 only
                'errors': self.errors
            }, f, indent=2)
        
        print(f"\nResults saved to: {output_file}")
        print("="*80)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', required=True, help='API Gateway URL')
    parser.add_argument('--users', type=int, default=100, help='Number of users')
    parser.add_argument('--ramp-up', type=int, default=30, help='Ramp up time (s)')
    parser.add_argument('--duration', type=int, default=120, help='Test duration (s)')
    
    args = parser.parse_args()
    
    tester = SimplifiedLoadTester(
        api_url=args.url,
        num_users=args.users,
        ramp_up=args.ramp_up,
        duration=args.duration
    )
    
    asyncio.run(tester.run())


if __name__ == "__main__":
    main()
