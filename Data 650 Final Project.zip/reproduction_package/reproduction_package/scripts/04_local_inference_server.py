"""
Local UrbanSound8K Inference Server
Runs the locally-trained model on your laptop
"""

import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import io
import json
import time
from flask import Flask, request, jsonify
from pathlib import Path
import psutil
import os

app = Flask(__name__)

# Model configuration
CLASS_NAMES = [
    'air_conditioner', 'car_horn', 'children_playing', 'dog_bark',
    'drilling', 'engine_idling', 'gun_shot', 'jackhammer',
    'siren', 'street_music'
]

# Image preprocessing (same as training)
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                       std=[0.229, 0.224, 0.225])
])

# Global model variable
model = None
device = None

def load_model(model_path):
    """Load the trained ResNet50 model"""
    global model, device
    
    print(f"Loading model from: {model_path}")
    
    # Detect device
    device = torch.device('cpu')  # Force CPU for fair comparison
    print(f"Using device: {device}")
    
    # Create model architecture
    model = models.resnet50(pretrained=False)
    num_features = model.fc.in_features
    model.fc = nn.Linear(num_features, len(CLASS_NAMES))
    
    # Load trained weights
    checkpoint = torch.load(model_path, map_location=device, weights_only=False)
    
    # Handle both formats: direct state_dict or full checkpoint
    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        # Full checkpoint with training info
        model.load_state_dict(checkpoint['model_state_dict'])
        print(f"Loaded checkpoint from epoch {checkpoint.get('epoch', 'unknown')}")
        print(f"Training accuracy: {checkpoint.get('train_acc', 'unknown'):.2f}%")
        print(f"Validation accuracy: {checkpoint.get('val_acc', 'unknown'):.2f}%")
    else:
        # Direct state_dict
        model.load_state_dict(checkpoint)
    
    model = model.to(device)
    model.eval()
    
    print("Model loaded successfully!")
    return model

@app.route('/ping', methods=['GET'])
def ping():
    """Health check endpoint"""
    return jsonify({'status': 'healthy'}), 200

@app.route('/invocations', methods=['POST'])
def predict():
    """Prediction endpoint (mimics SageMaker format)"""
    start_time = time.time()
    
    try:
        # Get CPU/Memory before inference
        cpu_before = psutil.cpu_percent(interval=0.1)
        mem_before = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024  # MB
        
        # Get image from request
        if 'file' in request.files:
            # Form data upload
            file = request.files['file']
            image_bytes = file.read()
        else:
            # Raw bytes
            image_bytes = request.get_data()
        
        # Load and preprocess image
        image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        image_tensor = transform(image).unsqueeze(0).to(device)
        
        # Run inference
        inference_start = time.time()
        with torch.no_grad():
            outputs = model(image_tensor)
            probabilities = torch.nn.functional.softmax(outputs, dim=1)
            predicted_idx = torch.argmax(probabilities, dim=1).item()
            confidence = probabilities[0][predicted_idx].item()
        
        inference_time = time.time() - inference_start
        
        # Get CPU/Memory after inference
        cpu_after = psutil.cpu_percent(interval=0.1)
        mem_after = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024  # MB
        
        # Prepare response
        result = {
            'predicted_class': CLASS_NAMES[predicted_idx],
            'predicted_class_id': predicted_idx,
            'confidence': confidence,
            'inference_time_ms': inference_time * 1000,
            'total_time_ms': (time.time() - start_time) * 1000,
            'system_metrics': {
                'cpu_usage_percent': cpu_after,
                'cpu_delta_percent': cpu_after - cpu_before,
                'memory_mb': mem_after,
                'memory_delta_mb': mem_after - mem_before
            },
            'all_probabilities': {
                CLASS_NAMES[i]: probabilities[0][i].item() 
                for i in range(len(CLASS_NAMES))
            }
        }
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({
            'error': str(e),
            'total_time_ms': (time.time() - start_time) * 1000
        }), 500

@app.route('/stats', methods=['GET'])
def stats():
    """System statistics"""
    return jsonify({
        'cpu_percent': psutil.cpu_percent(interval=1),
        'memory_percent': psutil.virtual_memory().percent,
        'memory_available_mb': psutil.virtual_memory().available / 1024 / 1024,
        'cpu_count': psutil.cpu_count()
    }), 200

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, required=True, 
                       help='Path to model.pth file')
    parser.add_argument('--port', type=int, default=5000,
                       help='Port to run on (default: 5000)')
    parser.add_argument('--host', type=str, default='127.0.0.1',
                       help='Host to bind to (default: 127.0.0.1)')
    
    args = parser.parse_args()
    
    # Load model
    load_model(args.model)
    
    print(f"\n{'='*80}")
    print(f"LOCAL INFERENCE SERVER STARTED")
    print(f"{'='*80}")
    print(f"Model: {args.model}")
    print(f"Endpoint: http://{args.host}:{args.port}/invocations")
    print(f"Health check: http://{args.host}:{args.port}/ping")
    print(f"Stats: http://{args.host}:{args.port}/stats")
    print(f"{'='*80}\n")
    
    # Run Flask app
    app.run(host=args.host, port=args.port, debug=False, threaded=True)
