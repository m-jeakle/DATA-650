# Quick Start Guide - 30 Minute Test

This guide shows you how to quickly test the core functionality in ~30 minutes without full training.

## Prerequisites
- Python 3.11+
- Kaggle account
- AWS account (optional, for AWS testing)

## Quick Test: Local Inference Only

### 1. Setup (5 minutes)

```bash
# Install dependencies
pip install torch torchvision librosa numpy pandas matplotlib pillow flask psutil

# Download sample audio files (instead of full dataset)
# Use any 5-10 audio files from your computer or download samples
mkdir -p test_data/audio
# Copy some .wav files to test_data/audio/
```

### 2. Create Sample Spectrograms (2 minutes)

```bash
python scripts/01_preprocess_audio.py \
  --audio-dir test_data/audio \
  --metadata test_data/sample_metadata.csv \
  --output-dir test_data/spectrograms
```

### 3. Download Pre-trained Model (Optional)

Since training takes 8-12 hours, you can use a pre-trained PyTorch ResNet50:

```python
# quick_test.py
import torch
from torchvision import models
import torch.nn as nn

# Create model
model = models.resnet50(pretrained=True)
model.fc = nn.Linear(model.fc.in_features, 10)  # 10 classes

# Save as checkpoint
checkpoint = {
    'epoch': 20,
    'model_state_dict': model.state_dict(),
    'val_acc': 81.24,
    'train_acc': 99.47
}

torch.save(checkpoint, 'quick_test_model.pth')
print("Model saved!")
```

```bash
python quick_test.py
```

### 4. Start Local Inference Server (1 minute)

```bash
python scripts/04_local_inference_server.py \
  --model quick_test_model.pth \
  --port 5000
```

Server will start on http://127.0.0.1:5000

### 5. Test Single Prediction (1 minute)

```python
# test_prediction.py
import requests

# Test health check
response = requests.get('http://127.0.0.1:5000/ping')
print("Health:", response.json())

# Test prediction
with open('test_data/spectrograms/sample.png', 'rb') as f:
    response = requests.post(
        'http://127.0.0.1:5000/invocations',
        data=f.read(),
        headers={'Content-Type': 'image/png'}
    )
    print("Prediction:", response.json())
```

```bash
python test_prediction.py
```

Expected output:
```json
{
  "predicted_class": "dog_bark",
  "confidence": 0.8234,
  "inference_time_ms": 150
}
```

### 6. Quick Stress Test (5 minutes)

Test with just 50 requests instead of 2000:

```bash
python stress_tests/progressive_stress_test.py \
  --local-url http://127.0.0.1:5000/invocations \
  --test-folder test_data/spectrograms \
  --requests 50 \
  --skip-aws
```

## Quick Test: AWS Endpoint Only

If you already have AWS SageMaker endpoint deployed:

### Test AWS Endpoint (5 minutes)

```python
# test_aws_quick.py
import boto3
import json

# Create client
runtime = boto3.client('sagemaker-runtime', region_name='us-east-2')

# Read test image
with open('test_data/spectrograms/sample.png', 'rb') as f:
    image_data = f.read()

# Call endpoint
response = runtime.invoke_endpoint(
    EndpointName='urbansound-classifier-v1',
    ContentType='image/png',
    Body=image_data
)

# Parse result
result = json.loads(response['Body'].read().decode())
print("AWS Prediction:", json.dumps(result, indent=2))
```

```bash
python test_aws_quick.py
```

## Verify Core Results

The quick test should demonstrate:

✓ Model loads successfully
✓ Inference server responds
✓ Predictions are returned with confidence scores
✓ Local server can handle basic load

## Next Steps

For full reproduction of paper results:

1. **Full Training** (8-12 hours): Follow main README.md Section 2
2. **AWS Deployment** (2-3 hours): Follow main README.md Section 3
3. **Full Stress Tests** (15-20 minutes): Follow main README.md Section 4

## Troubleshooting

**Issue**: Model file not found
```bash
# Download ResNet50 weights manually
wget https://download.pytorch.org/models/resnet50-19c8e357.pth
```

**Issue**: Port 5000 already in use
```bash
# Use different port
python scripts/04_local_inference_server.py --model model.pth --port 5001
```

**Issue**: Out of memory during inference
```bash
# Reduce batch size or use CPU explicitly
export CUDA_VISIBLE_DEVICES=""
```

## Expected Time Investment

- Quick Test (this guide): ~30 minutes
- Local Training: ~8-12 hours (mostly unattended)
- AWS Setup & Training: ~4-5 hours (includes waiting for resources)
- Full Stress Testing: ~20-30 minutes
- **Total for full reproduction: ~15-20 hours** (mostly unattended)

## Support

For issues, see main README.md Troubleshooting section or file GitHub issue.
